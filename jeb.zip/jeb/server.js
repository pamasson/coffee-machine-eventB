const express = require('express');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');

const app = express();
const port = 3000;

// Lire le fichier de configuration
const config = JSON.parse(fs.readFileSync('config.json', 'utf8'));

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// Route de base pour servir index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
})

// Démarrage du serveur
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});


// Route pour traiter le paramètre envoyé par le client
app.post('/process-param', (req, res) => {
  const param = req.body.param;

  
  exec(`"${config.probcliPath}" -eval "${param}"`, (error, stdout, stderr) => { 
    if (error) {
        return res.status(500).send({ error: error.message });
    }
    res.json({ result: stdout || stderr });
  });
});


  
